<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Poppins', sans-serif;">
    <nav class="navbar navbar-expand-lg navbar-light" style="background:#0081C9">
        <div class="container-fluid" style="font-family: 'Poppins', sans-serif;">
            <h1 style="color:white">SMK<span class="text shadow-sm" style="color:#BFEAF5">Mutu</span></h1>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="home"> Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about">About</a>
              </li>
            </ul>
        </nav>
        <div class="text-center">
        <img src="https://www.smkmutucikampek.sch.id/wp-content/uploads/2021/06/logo_mutu_png_transparant-removebg-preview-1.png" width="300px"  alt="">
    </div><br>
    <div class="text-center mt-3">
      <p><h6>SMK TI Muhammadiyah adalah salah satu dari beberapa sekolah menengah kejuruan swasta yang mengemban misi yang sama <br> dalam mencerdaskan anak bangsa. Dalam kiprahnya selama 16 tahun sejak berdirinya tahun 2003, SMK TI Muhammadiyah <br> Cikampek melaksanakan tugasnya sebagai pelaksana pendidikan tingkat menengah dan selama kurun waktu tersebut <br> SMK TI Muhammadiyah Cikampek melakukan pembenahan dalam semua bidang.</h6></p>
    </div>
    <footer class="bg-light mt-5 text-center text-lg-start">
      
    </footer>
</body>
</html>