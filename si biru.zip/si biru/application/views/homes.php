<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
</head>
<body style="font-family: 'Poppins', sans-serif;">
<nav class="navbar navbar-expand-lg navbar-light" style="background:#0081C9">
        <div class="container-fluid" style="font-family: 'Poppins', sans-serif;">
            <h1 style="color:white">SMK<span class="text shadow-sm" style="color:#BFEAF5">Mutu</span></h1>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="home"> Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about">About</a>
              </li>
            </ul>
        </nav>
    <div class="text-center">
        <img src="https://www.smkmutucikampek.sch.id/wp-content/uploads/2020/02/bg-masthead-1024x536.jpg" class="mt-5 img-fluid rounded-circle" width="700px"  alt="">
    </div><br>
    <div class="text-center mt-3">
      <h6>diatas ini, anggap SMK Mutu</h6>
    </div>
    <footer class="bg-light mt-5 text-center text-lg-start">
      
    </footer>
</body>
</html>