<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <title>arutala</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Yeseva+One&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body style="font-family: 'Poppins', sans-serif;">
    <div style="padding: 50px;">
    <br><br>
        <form action="home"  method="POST">
        <div class="container mt-3">
        <div class="row" >
        <div class="col-md-6 ">
        <div class="card my-6 shadow-lg">
            <form class="card-body cardbody-color p-lg-4 ">
            <h2 class="mb-3 mt-4 text-center">R E G I S T E R</h2>
            <div class="mb-3 mt-3 text-center">
                Nis : <br>
                <input class="rounded-3 border-light" type="text" name="nis" placeholder="nis" style="width: 300px;" required>
              </div>
              <div class="mb-3 mt-3 text-center">
                Nama : <br>
                <input class="rounded-3 border-light" type="text" name="nama" placeholder="nama" style="width: 300px;" required>
              </div>
              <div class="mb-3 mt-3 text-center">
                Username : <br>
                <input class="rounded-3 border-light" type="text" name="username" placeholder="username" style="width: 300px;" required>
              </div>
              <div class="mb-3 mt-3 text-center">
                Password : <br>
                <input class="rounded-3 border-light" type="password" name="password" placeholder="password" style="width: 300px;" required>
              </div>
              <div class="mb-3 mt-3 text-center">
                Kelas : <br>
                <input class="rounded-3 border-light" type="text" name="kelas" placeholder="kelas" style="width: 300px;" required>
              </div>
              <div class="text-center mt-3"> 
                <button type="submit" class="btn btn-success px-3 mb-3" style="width: 300px;">Register</button> <br>
                <p><i>Already have account? click <a href="login" class="text-danger">Login</a></i></p>
                </div>
              </div>
          </form>
        </div>
</body>
</html>