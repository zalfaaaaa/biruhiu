<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function enlog()
	{
		$this->load->view('enlogi');
	}
	public function enreg()
	{
		$this->load->view('enregi');
	}
	public function enho()
	{
		$this->load->view('homes');
	}
	public function ab()
	{
		$this->load->view('abt');
	}
}
